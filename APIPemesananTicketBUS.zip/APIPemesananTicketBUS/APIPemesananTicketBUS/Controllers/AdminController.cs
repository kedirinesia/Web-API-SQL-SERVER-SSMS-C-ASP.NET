﻿using APIPemesananTicketBUS.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIPemesananTicketBUS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {


        [HttpPost("login")]
      public ActionResult Login(string username,  string password,  IConfiguration conf) {
            //Contekan
            //public ActionResult Login([FromBody]Admin data, IConfiguration conf)
            /*  public ActionResult Login([FromQuery] string username, [FromQuery] string password)
              {*/
            //if (username == "pulung" && password == "oke")
            //{
            //    return Ok("Login berhasil");

            //}
            //else { return Ok("Gagal Login"); }

            //string username = data.nama;
            string nama = "";
            string email = "";

            var conn = new SqlConnection(conf.GetConnectionString("DefaultConnection"));
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from admin where username ='" + username + "' and password='" + password + "'", conn);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                nama = rd["nama"].ToString();
                email = rd["email"].ToString();
            }
            else
            {
                return Ok("Username atau password salah");
            }

            Admin object1 = new Admin();
            object1.username = username;
            object1.nama = nama;
            object1.email = email;
            object1.password = password;
            return Ok(object1);
            //return Ok("username : " + username + "\n nama : " + nama + "\n email: " + email + "\n password : " + password);
        }
        



        // GET: api/<AdminController>
        [HttpGet]
        public ActionResult<IEnumerable<Admin>> Get([FromServices] IConfiguration configuration)
        {
            var results = new List<Admin>();
            string connectionString = configuration.GetConnectionString("DefaultConnection");

             var conn = new SqlConnection(connectionString);
            conn.Open();
             var cmd = new SqlCommand("SELECT * FROM admin", conn);
             var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                results.Add(new Admin
                {
                    username =   rd["username"].ToString(),
                    nama =   rd["nama"].ToString(),
                    email =   rd["email"].ToString(),
                    password =   rd["password"].ToString()
                });
            }
            rd.Close();
            cmd.Dispose();
            conn.Close();
            conn.Dispose();
            return Ok(results);
        }


        // GET api/<AdminController>/5
        [HttpGet("{username}")]
        public IActionResult Get(string username, [FromServices] IConfiguration configuration)
        {
            var results = new List<Admin>();
            string connectionString = configuration.GetConnectionString("DefaultConnection");

            var conn = new SqlConnection(connectionString);
            conn.Open();

           // var cmd = new SqlCommand("SELECT * FROM admin WHERE username like '%"+username+"%'", conn);
            var cmd = new SqlCommand("SELECT * FROM admin WHERE username = '"+username+"'", conn);
            

            var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                results.Add(new Admin
                {
                    username = rd["username"].ToString(),
                    nama = rd["nama"].ToString(),
                    email = rd["email"].ToString(),
                    password = rd["password"].ToString()
                });
            }

            rd.Close();
            cmd.Dispose();
            conn.Close();
            conn.Dispose();

            return Ok(results);
        }


        // POST api/<AdminController>
        //[HttpPost]
        //public IActionResult Post([FromBody]   string nama, string email, string password , string username, [FromServices] IConfiguration configuration)
        //{
        //    //var results = new List<Admin>();
        //    //string connectionString = configuration.GetConnectionString("DefaultConnection");

        //    //var conn = new SqlConnection(connectionString);
        //    //conn.Open();

        //    //// var cmd = new SqlCommand("SELECT * FROM admin WHERE username like '%"+username+"%'", conn);
        //    //var cmd = new SqlCommand("insert into Admin values('"+username+"', '"+nama+"', '"+email+"', '"+password+"')", conn);
        //    //cmd.ExecuteNonQuery();
        //    //conn.Close();
        //    //conn.Dispose();
        //    return Ok ("Berhasil");
        //}
        [HttpPost]
        public IActionResult Post(string username, string nama, string email, string password,  [FromServices] IConfiguration configuration)
        {
            var results = new List<Admin>();
            string connectionString = configuration.GetConnectionString("DefaultConnection");

            var conn = new SqlConnection(connectionString);
            conn.Open();

            // var cmd = new SqlCommand("SELECT * FROM admin WHERE username like '%"+username+"%'", conn);
            var cmd = new SqlCommand("insert into Admin values('" + username + "', '" + nama + "', '" + email + "', '" + password + "')", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            conn.Dispose();
          //  return Ok("Berhasil");
            return Ok(  "Data Yang diinput:" +"\n\nUsername : " + username +
                "\nnama : " + nama + "\nemail : " + email + "\npassword : " + password);
        }

        // PUT api/<AdminController>/5
        [HttpPut("{usernamesaatini}")]
        public IActionResult Put(string usernameSaatini, string username, string nama, string email, string password, [FromServices] IConfiguration configuration)
        {
            string conn = configuration.GetConnectionString("DefaultConnection");

            var con = new SqlConnection(conn);
            con.Open();

            var cmd = new SqlCommand("update admin set username = '"+username+"', nama = '"+nama+"', email = '"+email+"', password= '"+password+"' where username = '"+usernameSaatini+"'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            con.Dispose();
            return Ok("Data Yang Di Update:" + "\n\nUsername : " + username +
                "\nnama : " + nama + "\nemail : " + email + "\npassword : " + password);
        }

        // DELETE api/<AdminController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
