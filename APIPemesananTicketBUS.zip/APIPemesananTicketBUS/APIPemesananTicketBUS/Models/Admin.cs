﻿namespace APIPemesananTicketBUS.Models
{
    public class Admin
    {
        public string username { get; set; }
        public string nama { get; set; }
        public string email { get; set; }
        public string password { get; set; }
    }
}
